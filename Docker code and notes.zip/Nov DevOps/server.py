# Function to add two numbers
def add_numbers(a, b):
    return a + b

# Input from user
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Calculate sum
result = add_numbers(num1, num2)

# Display the result
print(f"The sum of {num1} and {num2} is {result}")
